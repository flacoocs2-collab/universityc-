#include <iostream>
#include <string>

int main() {
    std::string courseName;
    int labNumber;

    std::cout << "Enter course name: ";
    std::getline(std::cin, courseName);

    std::cout << "Enter lab number: ";
    std::cin >> labNumber;

    std::cout << "Course: " << courseName 
              << " — Lab: " << labNumber << std::endl;

    return 0;
}
