#include <iostream>

int main() {
    std::cout << "========================\n";
    std::cout << "\n";
    std::cout << "     CS102 PROGRAM\n";
    std::cout << "\n";
    std::cout << "========================\n";

    return 0;
}
