#include <iostream>

int main() {
    std::string userInput;

    // Ask the user for input
    std::cout << "Enter something: ";
    std::getline(std::cin, userInput);

    // Display the input
    std::cout << "You entered: " << userInput << std::endl;

    return 0;
}
