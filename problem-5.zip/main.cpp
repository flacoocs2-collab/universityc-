#include <iostream>
#include <string>

int main() {
    std::string city;
    std::string country;

    std::cout << "Enter your city: ";
    std::cin >> city;

    std::cout << "Enter your country: ";
    std::cin >> country;

    std::cout << city << "\n" << country << std::endl;

    return 0;
}
