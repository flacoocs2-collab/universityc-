#include <iostream>
#include <string>

int main() {
    std::string fullName;
    std::string studentID;
    std::string major;
    double gpa;

    std::cout << "Enter full name: ";
    std::getline(std::cin, fullName);

    std::cout << "Enter student ID: ";
    std::getline(std::cin, studentID);

    std::cout << "Enter major: ";
    std::getline(std::cin, major);

    std::cout << "Enter GPA: ";
    std::cin >> gpa;

    std::cout << "------------------------------------\n\n";
    std::cout << "    STUDENT INFORMATION\n\n";
    std::cout << "------------------------------------\n";
    std::cout << "Name : " << fullName << std::endl;
    std::cout << "Student ID : " << studentID << std::endl;
    std::cout << "Major : " << major << std::endl;
    std::cout << "GPA : " << gpa << std::endl;
    std::cout << "------------------------------------\n";

    return 0;
}
